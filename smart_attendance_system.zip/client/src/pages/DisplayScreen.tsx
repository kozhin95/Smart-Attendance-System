import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, CheckCircle, AlertCircle } from 'lucide-react';

interface AttendanceRecord {
  id: number;
  studentName: string;
  studentPhoto: string;
  className: string;
  status: 'present' | 'absent' | 'late' | 'excused';
  timestamp: Date;
}

export default function DisplayScreen() {
  const [currentRecord, setCurrentRecord] = useState<AttendanceRecord | null>(null);
  const [showAnimation, setShowAnimation] = useState(false);

  // Simulate receiving attendance records
  useEffect(() => {
    const mockRecord: AttendanceRecord = {
      id: 1,
      studentName: 'Ahmed Hassan',
      studentPhoto: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ahmed',
      className: 'Class 1A',
      status: 'present',
      timestamp: new Date(),
    };

    setCurrentRecord(mockRecord);
    setShowAnimation(true);

    const timer = setTimeout(() => {
      setShowAnimation(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return 'bg-green-100 border-green-300';
      case 'absent':
        return 'bg-red-100 border-red-300';
      case 'late':
        return 'bg-yellow-100 border-yellow-300';
      case 'excused':
        return 'bg-blue-100 border-blue-300';
      default:
        return 'bg-gray-100 border-gray-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'present':
        return <CheckCircle className="w-12 h-12 text-green-600" />;
      case 'absent':
        return <AlertCircle className="w-12 h-12 text-red-600" />;
      case 'late':
        return <Clock className="w-12 h-12 text-yellow-600" />;
      default:
        return <CheckCircle className="w-12 h-12 text-blue-600" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'present':
        return 'Present';
      case 'absent':
        return 'Absent';
      case 'late':
        return 'Late';
      case 'excused':
        return 'Excused';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 to-blue-700 flex items-center justify-center p-4">
      {currentRecord && (
        <div
          className={`transition-all duration-500 transform ${
            showAnimation ? 'scale-100 opacity-100' : 'scale-95 opacity-50'
          }`}
        >
          <Card className={`w-full max-w-md shadow-2xl border-4 ${getStatusColor(currentRecord.status)}`}>
            <CardContent className="p-8">
              <div className="text-center space-y-6">
                {/* Status Icon */}
                <div className="flex justify-center">
                  {getStatusIcon(currentRecord.status)}
                </div>

                {/* Student Photo */}
                <div className="flex justify-center">
                  <img
                    src={currentRecord.studentPhoto}
                    alt={currentRecord.studentName}
                    className="w-32 h-32 rounded-full border-4 border-white shadow-lg object-cover"
                  />
                </div>

                {/* Student Name */}
                <div>
                  <h2 className="text-3xl font-bold text-gray-900">{currentRecord.studentName}</h2>
                </div>

                {/* Class Information */}
                <div className="bg-white bg-opacity-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600">Class</p>
                  <p className="text-2xl font-semibold text-gray-900">{currentRecord.className}</p>
                </div>

                {/* Status */}
                <div className="bg-white bg-opacity-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600">Status</p>
                  <p className="text-2xl font-bold text-gray-900">{getStatusText(currentRecord.status)}</p>
                </div>

                {/* Time */}
                <div className="text-sm text-gray-600">
                  <p>{currentRecord.timestamp.toLocaleTimeString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {!currentRecord && (
        <div className="text-center text-white">
          <Clock className="w-16 h-16 mx-auto mb-4 opacity-50" />
          <p className="text-2xl font-semibold">Waiting for attendance records...</p>
        </div>
      )}
    </div>
  );
}
