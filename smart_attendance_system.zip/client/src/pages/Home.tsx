import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Camera, BarChart3, Users, Bell, Clock } from "lucide-react";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="max-w-md w-full">
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="mb-6">
              <Camera className="w-16 h-16 mx-auto text-indigo-600" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Smart Attendance System</h1>
            <p className="text-gray-600 mb-8">
              Automated face recognition-based attendance tracking for educational institutions
            </p>
            <a href={getLoginUrl()}>
              <Button size="lg" className="w-full">
                Sign In to Continue
              </Button>
            </a>
          </div>
        </div>
      </div>
    );
  }

  const isAdmin = user?.role === 'admin';

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <Camera className="w-8 h-8 text-indigo-600" />
              <h1 className="text-2xl font-bold text-gray-900">Smart Attendance System</h1>
            </div>
            <div className="text-sm text-gray-600">
              Welcome, <span className="font-semibold">{user?.name || 'User'}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Display Screen */}
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setLocation('/display')}>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-indigo-600" />
                <CardTitle>Display Screen</CardTitle>
              </div>
              <CardDescription>Real-time attendance display</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Shows student photo and class information when attendance is recorded. Perfect for classroom deployment.
              </p>
            </CardContent>
          </Card>

          {/* Attendance Recording */}
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setLocation('/attendance')}>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-green-600" />
                <CardTitle>Record Attendance</CardTitle>
              </div>
              <CardDescription>Face recognition-based check-in</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Use face recognition to automatically identify and record student attendance with confidence scores.
              </p>
            </CardContent>
          </Card>

          {isAdmin && (
            <>
              {/* Admin Dashboard */}
              <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setLocation('/dashboard')}>
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-purple-600" />
                    <CardTitle>Dashboard</CardTitle>
                  </div>
                  <CardDescription>Attendance statistics and reports</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    View attendance statistics, generate reports, and analyze attendance patterns by class and date.
                  </p>
                </CardContent>
              </Card>

              {/* Student Management */}
              <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setLocation('/students')}>
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    <CardTitle>Manage Students</CardTitle>
                  </div>
                  <CardDescription>Add and manage student records</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    Register new students, upload photos, enroll faces for recognition, and manage class assignments.
                  </p>
                </CardContent>
              </Card>

              {/* Notifications */}
              <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setLocation('/notifications')}>
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    <Bell className="w-5 h-5 text-orange-600" />
                    <CardTitle>Notifications</CardTitle>
                  </div>
                  <CardDescription>Parent notifications and alerts</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    Configure and monitor automated notifications sent to parents for absences and late arrivals.
                  </p>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
