import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, date } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "teacher", "parent"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Grades/Levels in the school (e.g., Grade 1, Grade 2, etc.)
 */
export const grades = mysqlTable("grades", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(), // e.g., "Grade 1", "Grade 2"
  level: int("level").notNull(), // Numeric level for sorting
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Grade = typeof grades.$inferSelect;
export type InsertGrade = typeof grades.$inferInsert;

/**
 * Classes in the school (e.g., Class 1A, Class 1B)
 */
export const classes = mysqlTable("classes", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(), // e.g., "Class 1A"
  gradeId: int("gradeId").notNull(), // Foreign key to grades
  teacherId: int("teacherId"), // Optional teacher assignment
  roomNumber: varchar("roomNumber", { length: 50 }),
  capacity: int("capacity"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Class = typeof classes.$inferSelect;
export type InsertClass = typeof classes.$inferInsert;

/**
 * Students in the school
 */
export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  enrollmentNumber: varchar("enrollmentNumber", { length: 100 }).notNull().unique(),
  classId: int("classId").notNull(), // Current class assignment
  gradeId: int("gradeId").notNull(),
  dateOfBirth: date("dateOfBirth"),
  photoUrl: text("photoUrl"), // S3 URL to student photo
  faceEncodingUrl: text("faceEncodingUrl"), // S3 URL to face encoding data for recognition
  status: mysqlEnum("status", ["active", "inactive", "transferred"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;

/**
 * Parents/Guardians of students
 */
export const parents = mysqlTable("parents", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phoneNumber: varchar("phoneNumber", { length: 20 }),
  relationship: varchar("relationship", { length: 50 }), // e.g., "Mother", "Father", "Guardian"
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Parent = typeof parents.$inferSelect;
export type InsertParent = typeof parents.$inferInsert;

/**
 * Relationship between students and parents
 */
export const studentParents = mysqlTable("studentParents", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull(),
  parentId: int("parentId").notNull(),
  isPrimary: boolean("isPrimary").default(false), // Primary contact for notifications
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StudentParent = typeof studentParents.$inferSelect;
export type InsertStudentParent = typeof studentParents.$inferInsert;

/**
 * Class periods/time slots (e.g., 9:00 AM - 10:00 AM)
 */
export const classPeriods = mysqlTable("classPeriods", {
  id: int("id").autoincrement().primaryKey(),
  classId: int("classId").notNull(),
  periodName: varchar("periodName", { length: 100 }).notNull(), // e.g., "Period 1", "Morning Session"
  startTime: varchar("startTime", { length: 10 }).notNull(), // HH:MM format
  endTime: varchar("endTime", { length: 10 }).notNull(), // HH:MM format
  dayOfWeek: int("dayOfWeek"), // 0-6 (Sunday-Saturday), null for all days
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ClassPeriod = typeof classPeriods.$inferSelect;
export type InsertClassPeriod = typeof classPeriods.$inferInsert;

/**
 * Attendance records
 */
export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull(),
  classId: int("classId").notNull(),
  periodId: int("periodId"), // Reference to class period
  recordedAt: timestamp("recordedAt").defaultNow().notNull(), // When attendance was recorded
  date: date("date").notNull(), // Date of attendance
  status: mysqlEnum("status", ["present", "absent", "late", "excused"]).default("present").notNull(),
  notes: text("notes"), // Optional notes about the attendance
  recognitionConfidence: decimal("recognitionConfidence", { precision: 5, scale: 2 }), // Face recognition confidence score
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = typeof attendance.$inferInsert;

/**
 * Notification history
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  parentId: int("parentId").notNull(),
  studentId: int("studentId").notNull(),
  type: mysqlEnum("type", ["absence", "late", "custom"]).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  message: text("message").notNull(),
  status: mysqlEnum("status", ["pending", "sent", "failed"]).default("pending").notNull(),
  sentAt: timestamp("sentAt"),
  failureReason: text("failureReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Absence records for tracking and notifications
 */
export const absences = mysqlTable("absences", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull(),
  classId: int("classId").notNull(),
  date: date("date").notNull(),
  periodId: int("periodId"),
  reason: varchar("reason", { length: 255 }), // e.g., "Sick", "Family Emergency"
  notificationSent: boolean("notificationSent").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Absence = typeof absences.$inferSelect;
export type InsertAbsence = typeof absences.$inferInsert;
