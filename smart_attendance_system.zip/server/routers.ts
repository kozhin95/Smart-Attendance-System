import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as dbModule from "./db";
import { students, attendance } from "../drizzle/schema";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ GRADES ============
  grades: router({
    list: publicProcedure.query(async () => {
      return await dbModule.getAllGrades();
    }),
    getById: publicProcedure.input(z.number()).query(async ({ input }) => {
      return await dbModule.getGradeById(input);
    }),
  }),

  // ============ CLASSES ============
  classes: router({
    list: publicProcedure.query(async () => {
      return await dbModule.getAllClasses();
    }),
    getById: publicProcedure.input(z.number()).query(async ({ input }) => {
      return await dbModule.getClassById(input);
    }),
    getByGrade: publicProcedure.input(z.number()).query(async ({ input }) => {
      return await dbModule.getClassesByGrade(input);
    }),
  }),

  // ============ STUDENTS ============
  students: router({
    list: publicProcedure.query(async () => {
      return await dbModule.getAllStudents();
    }),
    getById: publicProcedure.input(z.number()).query(async ({ input }) => {
      return await dbModule.getStudentById(input);
    }),
    getByClass: publicProcedure.input(z.number()).query(async ({ input }) => {
      return await dbModule.getStudentsByClass(input);
    }),
    create: protectedProcedure.input(z.object({
      name: z.string(),
      enrollmentNumber: z.string(),
      classId: z.number(),
      gradeId: z.number(),
      dateOfBirth: z.string().optional(),
      photoUrl: z.string().optional(),
      faceEncodingUrl: z.string().optional(),
    })).mutation(async ({ input }) => {
      const db_instance = await dbModule.getDb();
      if (!db_instance) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Database unavailable' });
      
      const result = await db_instance.insert(students).values({
        name: input.name,
        enrollmentNumber: input.enrollmentNumber,
        classId: input.classId,
        gradeId: input.gradeId,
        dateOfBirth: input.dateOfBirth ? new Date(input.dateOfBirth) : null,
        photoUrl: input.photoUrl || null,
        faceEncodingUrl: input.faceEncodingUrl || null,
        status: 'active',
      });
      return result;
    }),
  }),

  // ============ ATTENDANCE ============
  attendance: router({
    getByDate: publicProcedure.input(z.object({
      classId: z.number(),
      date: z.string(),
    })).query(async ({ input }) => {
      const date = new Date(input.date);
      return await dbModule.getAttendanceByDate(input.classId, date);
    }),
    getStudentHistory: publicProcedure.input(z.object({
      studentId: z.number(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
    })).query(async ({ input }) => {
      const startDate = input.startDate ? new Date(input.startDate) : undefined;
      const endDate = input.endDate ? new Date(input.endDate) : undefined;
      return await dbModule.getStudentAttendanceHistory(input.studentId, startDate, endDate);
    }),
    getClassStats: publicProcedure.input(z.object({
      classId: z.number(),
      date: z.string(),
    })).query(async ({ input }) => {
      const date = new Date(input.date);
      return await dbModule.getClassAttendanceStats(input.classId, date);
    }),
    record: protectedProcedure.input(z.object({
      studentId: z.number(),
      classId: z.number(),
      periodId: z.number().optional(),
      status: z.enum(['present', 'absent', 'late', 'excused']),
      recognitionConfidence: z.number().optional(),
      notes: z.string().optional(),
    })).mutation(async ({ input }) => {
      const db_instance = await dbModule.getDb();
      if (!db_instance) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Database unavailable' });
      
      const today = new Date();
      const attendanceValues: any = {
        studentId: input.studentId,
        classId: input.classId,
        date: today,
        status: input.status,
      };
      
      if (input.periodId !== undefined) {
        attendanceValues.periodId = input.periodId;
      }
      if (input.recognitionConfidence !== undefined) {
        attendanceValues.recognitionConfidence = parseFloat(input.recognitionConfidence.toString());
      }
      if (input.notes !== undefined) {
        attendanceValues.notes = input.notes;
      }
      
      const result = await db_instance.insert(attendance).values(attendanceValues);
      
      if (input.status === 'absent') {
        const student = await dbModule.getStudentById(input.studentId);
        if (student) {
          const parents = await dbModule.getParentsByStudent(input.studentId);
          for (const { parent } of parents) {
            await dbModule.createNotification({
              parentId: parent.id,
              studentId: input.studentId,
              type: 'absence',
              subject: `Absence Alert: ${student.name}`,
              message: `Your child ${student.name} was marked absent on ${new Date().toLocaleDateString()}.`,
            });
          }
        }
      }
      
      return result;
    }),
  }),

  // ============ PARENTS ============
  parents: router({
    getByStudent: publicProcedure.input(z.number()).query(async ({ input }) => {
      return await dbModule.getParentsByStudent(input);
    }),
    getPrimaryByStudent: publicProcedure.input(z.number()).query(async ({ input }) => {
      return await dbModule.getPrimaryParentByStudent(input);
    }),
  }),

  // ============ NOTIFICATIONS ============
  notifications: router({
    getByParent: publicProcedure.input(z.number()).query(async ({ input }) => {
      return await dbModule.getNotificationsByParent(input);
    }),
    create: protectedProcedure.input(z.object({
      parentId: z.number(),
      studentId: z.number(),
      type: z.enum(['absence', 'late', 'custom']),
      subject: z.string(),
      message: z.string(),
    })).mutation(async ({ input }) => {
      return await dbModule.createNotification(input);
    }),
  }),

  // ============ CLASS PERIODS ============
  classPeriods: router({
    getByClass: publicProcedure.input(z.number()).query(async ({ input }) => {
      return await dbModule.getClassPeriods(input);
    }),
    getById: publicProcedure.input(z.number()).query(async ({ input }) => {
      return await dbModule.getClassPeriodById(input);
    }),
  }),
});

export type AppRouter = typeof appRouter;
